
import React from 'react';
import { Link } from 'react-router-dom';

function Navigation({ isLoggedIn, onLogout }) {
  return (
    <nav>
      <ul>
        <li>
          <Link to="/everyone">Everyone</Link>
        </li>
        {isLoggedIn ? (
          <>
            <li>
              <Link to="/add-item">Add Item</Link>
            </li>
            <li>
              <button onClick={onLogout}>Logout</button>
            </li>
          </>
        ) : (
          <>
            <li>
              <Link to="/login">Login</Link>
            </li>
            <li>
              <Link to="/register">Register</Link>
            </li>
          </>
        )}
      </ul>
    </nav>
  );
}

export default Navigation;
