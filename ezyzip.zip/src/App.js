// use for first question 


// import React, { useState ,useEffect} from "react";
// import Card from "./Components/Card";

// import data from './Components/data.json'



// const App = () => {
//   return (
//     <div className="App">
//       <h1>Card Component</h1>
//       <div className="card-container">
//         {data.map((item) => (
//           <Card key={item.id} title={item.title} content={item.content} />
//         ))}
//       </div>
//     </div>
//   );
// };

// export default App;





// use for second question

// import React, { useState, useEffect } from "react";
// import Questions2 from "./Components/Questions2";
// function App() {
//   const [isLoading, setIsLoading] = useState(true);
//   const [data, setData] = useState(null);

//   useEffect(() => {
    
//     setTimeout(() => {
      
//       setIsLoading(false);
//       setData("Loaded Data"); 
//     }, 1000); 
//   }, []);

//   return (
//     <div className="App">
//       <h1>Your App</h1>
//       {isLoading ? (
        
//         < Questions2/>
//       ) : (
        
//         <div>
          
//           {data && <p>{data}</p>}
//         </div>
//       )}
//     </div>
//   );
// }

// export default App;







// question third 


// import React, { useState } from "react";
// import "./App3.css"

// function App() {
//   const [tasks, setTasks] = useState([
//     { id: 1, title: "Buy groceries" },
//     { id: 2, title: "Walk the dog" },
//     { id: 3, title: "Clean the house" },
//   ]);

//   const [searchTerm, setSearchTerm] = useState("");

//   const addTask = (title) => {
//     const newTask = {
//       id: tasks.length + 1,
//       title: title,
//     };
//     setTasks([...tasks, newTask]);
//   };

//   const handleSearch = (event) => {
//     setSearchTerm(event.target.value);
//   };

//   const filteredTasks = tasks.filter((task) =>
//     task.title.toLowerCase().includes(searchTerm.toLowerCase())
//   );

//   return (
//     <div className="App">
//       <h1>To-Do List</h1>
//       <input
//         type="text"
//         placeholder="Search tasks..."
//         value={searchTerm}
//         onChange={handleSearch}
//       />
//       <ul>
//         {filteredTasks.map((task) => (
//           <li key={task.id}>{task.title}</li>
//         ))}
//       </ul>
//       <div>
//         <input
//           type="text"
//           placeholder="Add a new task..."
//           onKeyDown={(e) => {
//             if (e.key === "Enter" && e.target.value.trim() !== "") {
//               addTask(e.target.value);
//               e.target.value = "";
//             }
//           }}
//         />
//       </div>
//     </div>
//   );
// }

// export default App;




// // question 5


// import React from 'react';
// import CheckboxForm from './Components/CheckboxForm';

// function App() {
//   return (
//     <div className="App">
//       <CheckboxForm />
//     </div>
//   );
// }

// export default App;




//question 4












