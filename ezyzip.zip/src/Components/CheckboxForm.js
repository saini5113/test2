import React, { useState, useEffect } from 'react';

function useCheckboxValidation(totalCheckboxes) {
  const [checkboxValues, setCheckboxValues] = useState(Array(totalCheckboxes).fill(false));
  const [isChecked, setIsChecked] = useState(false);

  useEffect(() => {
   
    const isAllChecked = checkboxValues.every((value) => value);
    setIsChecked(isAllChecked);
  }, [checkboxValues]);

  const handleCheckboxChange = (index) => {
    const updatedValues = [...checkboxValues];
    updatedValues[index] = !updatedValues[index];
    setCheckboxValues(updatedValues);
  };

  return { isChecked, checkboxValues, handleCheckboxChange };
}

function CheckboxForm() {
  const totalCheckboxes = 12;
  const { isChecked, checkboxValues, handleCheckboxChange } = useCheckboxValidation(totalCheckboxes);

  return (
    <div>
      <h1>Checkbox Validation</h1>
      <div>
        {Array.from({ length: totalCheckboxes }, (_, index) => (
          <label key={index}>
            <input
              type="checkbox"
              checked={checkboxValues[index]}
              onChange={() => handleCheckboxChange(index)}
            />
            Checkbox {index + 1}
          </label>
        ))}
      </div>
      <p>All checkboxes are checked: {isChecked ? 'Yes' : 'No'}</p>
    </div>
  );
}

export default CheckboxForm;
